// Importing React classes and functions from node modules
import React from "react";

// Functional Component for Signup Page
function sign_up(){

    // Returns HTML elements and content to display on the pages
    return(
        <h2>SignUp Here</h2>
    );
}

// Export the sign-up Function
export default sign_up;